package org.notabug.lifeuser.ArraysOfCinemas.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.apmem.tools.layouts.FlowLayout;
import org.notabug.lifeuser.ArraysOfCinemas.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class FilterActivity extends AppCompatActivity {

    ArrayList withGenres = new ArrayList();
    ArrayList withoutGenres = new ArrayList();

    public static final String FILTER_PREFERENCES = "filter_preferences";
    public static final String FILTER_SORT = "filter_sort";
    public static final String FILTER_CATEGORIES = "filter_categories";
    public static final String FILTER_DATES = "filter_dates";
    public static final String FILTER_START_DATE = "filter_start_date";
    public static final String FILTER_END_DATE = "filter_end_date";
    public static final String FILTER_WITH_GENRES = "filter_with_genres";
    public static final String FILTER_WITHOUT_GENRES = "filter_without_genres";
    public static final String FILTER_WITH_KEYWORDS = "filter_with_keywords";
    public static final String FILTER_WITHOUT_KEYWORDS = "filter_without_keywords";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        Intent intent = getIntent();

        if (intent.getBooleanExtra("categories", false)) {
            LinearLayout categoriesLayout = (LinearLayout) findViewById(R.id.categoriesLayout);
            categoriesLayout.setVisibility(View.VISIBLE);
        }

        if (!intent.getBooleanExtra("most_popular", true)) {
            RadioButton radioButton = (RadioButton) findViewById(R.id.most_popular);
            radioButton.setText(getString(R.string.default_sort));
        }

        if (!intent.getBooleanExtra("dates", true)) {
            RelativeLayout dateViewLayout = (RelativeLayout) findViewById(R.id.dateViewLayout);
            dateViewLayout.setVisibility(View.GONE);
        }

        if (!intent.getBooleanExtra("keywords", true)) {
            View separator = findViewById(R.id.genreViewSeparator);
            RelativeLayout advancedTitle = (RelativeLayout) findViewById(R.id.advancedTitle);

            separator.setVisibility(View.GONE);
            advancedTitle.setVisibility(View.GONE);
        }

        SharedPreferences sharedPreferences = getSharedPreferences("GenreList", Context.MODE_PRIVATE);
        String stringGenreArray = sharedPreferences.getString("genreJSONArrayList", null);

        if (stringGenreArray != null) {
            try {
                FlowLayout flowLayout = (FlowLayout) findViewById(R.id.genreButtons);
                JSONArray genreArray = new JSONArray(stringGenreArray);
                for (int i = 0; i < genreArray.length(); i++) {
                    JSONObject genre = genreArray.getJSONObject(i);

                    Button button = new Button(this);
                    button.setText(genre.getString("name"));
                    button.setId(Integer.parseInt(genre.getString("id")));
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Button genreButton = (Button) v;
                            int buttonId = genreButton.getId();

                            if(withGenres.contains(buttonId)) {
                                withGenres.remove((Integer) buttonId);
                                withoutGenres.add(buttonId);

                                genreButton.getBackground().setColorFilter(getResources().getColor(R.color.colorRed), PorterDuff.Mode.SRC_ATOP);
                                genreButton.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_close), null, null, null);
                            } else if(withoutGenres.contains(buttonId)) {
                                withoutGenres.remove((Integer) buttonId);

                                genreButton.getBackground().clearColorFilter();
                                genreButton.setCompoundDrawablesWithIntrinsicBounds(null,
                                        null, null, null);
                                genreButton.setTextColor(Color.BLACK);
                            } else {
                                withGenres.add(buttonId);

                                genreButton.getBackground().setColorFilter(getResources().getColor(R.color.colorGreen), PorterDuff.Mode.SRC_ATOP);
                                genreButton.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_check), null, null, null);
                                genreButton.setTextColor(Color.WHITE);
                            }
                        }
                    });
                    flowLayout.addView(button);
                }
            } catch (JSONException je) {
                je.printStackTrace();
            }
        }

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }

        retrieveFilterPreferences();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                saveFilterPreferences();
                setResult(RESULT_OK);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        saveFilterPreferences();
        setResult(RESULT_OK);
        this.finish();
    }


    private void saveFilterPreferences() {
        SharedPreferences sharedPreferences
                = getSharedPreferences(FILTER_PREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();

        prefsEditor.putString(FILTER_WITH_GENRES, withGenres.toString());

        prefsEditor.putString(FILTER_WITHOUT_GENRES, withoutGenres.toString());

        prefsEditor.putString(FILTER_SORT, getSelectedRadioButton(
                (RadioGroup) findViewById(R.id.sortSelection)
        ));

        prefsEditor.putString(FILTER_CATEGORIES, getSelectedCheckBoxes(
                ((CheckBox) findViewById(R.id.watchingCheckBox)),
                ((CheckBox) findViewById(R.id.watchedCheckBox)),
                ((CheckBox) findViewById(R.id.plannedToWatchCheckBox)),
                ((CheckBox) findViewById(R.id.onHoldCheckBox)),
                ((CheckBox) findViewById(R.id.droppedCheckBox))
        ).toString());

        prefsEditor.putString(FILTER_DATES, getSelectedCheckBox(
                ((CheckBox) findViewById(R.id.theaterCheckBox)),
                ((CheckBox) findViewById(R.id.twoDatesCheckBox))
        ));

        EditText withKeywords = (EditText) findViewById(R.id.withKeywords);
        EditText withoutKeywords = (EditText) findViewById(R.id.withoutKeywords);

        prefsEditor.putString(FILTER_WITH_KEYWORDS, withKeywords.getText().toString());
        prefsEditor.putString(FILTER_WITHOUT_KEYWORDS, withoutKeywords.getText().toString());

        prefsEditor.commit();
    }


    private String getSelectedCheckBox(CheckBox... checkBoxes) {
        for(CheckBox checkBox : checkBoxes) {
            if(checkBox.isChecked()) {
                return checkBox.getTag().toString();
            }
        }

        return null;
    }

    private ArrayList<String> getSelectedCheckBoxes(CheckBox... checkBoxes) {
        ArrayList<String> checkBoxArray = new ArrayList<String>();
        for (CheckBox checkBox : checkBoxes) {
            if (checkBox.isChecked()) {
                checkBoxArray.add(checkBox.getTag().toString());
            }
        }

        return checkBoxArray;
    }


    private String getSelectedRadioButton(RadioGroup radioGroup) {
        if (radioGroup.getCheckedRadioButtonId() != -1) {
            int id = radioGroup.getCheckedRadioButtonId();
            RadioButton radioButton = (RadioButton) radioGroup.findViewById(id);
            return radioButton.getTag().toString();
        } else {
            return null;
        }
    }


    private void selectRadioButtonByTag(String tag, RadioGroup radioGroup) {
        int count = radioGroup.getChildCount();
        for (int i = 0; i < count; i++) {
            RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
            if (radioButton.getTag().toString().equals(tag)) {
                radioGroup.check(radioButton.getId());
            }
        }
    }


    private void selectCheckBoxByTag(ArrayList<String> arrayList, ViewGroup parent) {
        int count = parent.getChildCount();
        for (int i = 0; i < count; i++) {
            CheckBox checkBox = (CheckBox) parent.getChildAt(i);
            if (arrayList.contains(checkBox.getTag().toString())) {
                checkBox.setChecked(true);
            }
        }
    }

    private void retrieveFilterPreferences() {
        SharedPreferences sharedPreferences
                = getSharedPreferences(FILTER_PREFERENCES, Context.MODE_PRIVATE);

        withGenres = convertStringToIntegerArrayList(sharedPreferences.getString(FILTER_WITH_GENRES, null), ", ");
        withoutGenres = convertStringToIntegerArrayList(sharedPreferences.getString(FILTER_WITHOUT_GENRES, null), ", ");

        String sortTag = sharedPreferences.getString(FILTER_SORT, null);
        if (sortTag != null) {
            selectRadioButtonByTag(sortTag, (RadioGroup) findViewById(R.id.sortSelection));
        } else {
            selectRadioButtonByTag("most_popular", (RadioGroup) findViewById(R.id.sortSelection));
        }

        String categoriesTags = sharedPreferences.getString(FILTER_CATEGORIES, null);
        if (categoriesTags != null && !categoriesTags.equals("[]")) {
            ArrayList<String> categoryTagArray = convertStringToArrayList(categoriesTags, ", ");
                selectCheckBoxByTag(categoryTagArray, (ViewGroup) findViewById(R.id.categoryCheckBoxesLayout));
        }

        String dateTag = sharedPreferences.getString(FILTER_DATES, null);
        if (dateTag != null) {
            if (dateTag.equals("in_theater")) {
                CheckBox checkBox = (CheckBox) findViewById(R.id.theaterCheckBox);
                checkBox.setChecked(true);
            } else {
                CheckBox checkBox = (CheckBox) findViewById(R.id.twoDatesCheckBox);
                checkBox.setChecked(true);
            }
        }

        String startDate;
        if ((startDate = sharedPreferences.getString(FILTER_START_DATE, null)) != null) {
            Button button = (Button) findViewById(R.id.startDateButton);
            button.setText(startDate);
        }

        String endDate;
        Button button = (Button) findViewById(R.id.endDateButton);
        if ((endDate = sharedPreferences.getString(FILTER_END_DATE, null)) != null) {
            button.setText(endDate);
        } else {
            button.setText("2000-01-01");
        }

        if(withGenres != null) {
            for (int i = 0; i < withGenres.size(); i++) {
                int id = (int) withGenres.get(i);

                Button genreButton = (Button) findViewById(id);
                genreButton.getBackground().setColorFilter(getResources().getColor(R.color.colorGreen), PorterDuff.Mode.SRC_ATOP);
                genreButton.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_check), null, null, null);
                genreButton.setTextColor(Color.WHITE);
            }
        }

        if(withoutGenres != null) {
            for (int i = 0; i < withoutGenres.size(); i++) {
                int id = (int) withoutGenres.get(i);

                Button genreButton = (Button) findViewById(id);
                genreButton.getBackground().setColorFilter(getResources().getColor(R.color.colorRed), PorterDuff.Mode.SRC_ATOP);
                genreButton.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_close), null, null, null);
                genreButton.setTextColor(Color.WHITE);
            }
        }

        String withKeywords;
        if ((withKeywords = sharedPreferences.getString(FILTER_WITH_KEYWORDS, null)) != null) {
            EditText withKeywordsView = (EditText) findViewById(R.id.withKeywords);
            withKeywordsView.setText(withKeywords);
        }

        String withoutKeywords;
        if ((withoutKeywords = sharedPreferences.getString(FILTER_WITHOUT_KEYWORDS, null)) != null) {
            EditText withoutKeywordsView = (EditText) findViewById(R.id.withoutKeywords);
            withoutKeywordsView.setText(withoutKeywords);
        }
    }


    public static ArrayList<Integer> convertStringToIntegerArrayList(String array, String splitArg) {
        ArrayList idArrayList = new ArrayList<Integer>();
        if(array != null) {
            String arrayList = array.substring(1, array.length() - 1);
            if(!arrayList.equals("")) {
                String[] ids = arrayList.split(splitArg);
                for (int i = 0; i < ids.length; i++) {
                    idArrayList.add(Integer.parseInt(ids[i]));
                }
            }
        }

        return idArrayList;
    }

    public static ArrayList<String> convertStringToArrayList(String array, String splitArg) {
        ArrayList arrayList = new ArrayList<String>();
        if (array != null) {
            array = array.substring(1, array.length() - 1);
            if (!array.equals("")) {
                String[] items = array.split(splitArg);
                for (String item : items) {
                    arrayList.add(item);
                }
            }
        }

        if (arrayList.size() == 0) {
            return null;
        }

        return arrayList;
    }


    public void checkBoxSelected(View view) {
        CheckBox theaterCheckBox = (CheckBox) findViewById(R.id.theaterCheckBox);
        CheckBox twoDatesCheckBox = (CheckBox) findViewById(R.id.twoDatesCheckBox);

        TableLayout tableLayout = (TableLayout) findViewById(R.id.dateDetailsLayout);
        if(view.getId() == twoDatesCheckBox.getId()) {
            if(twoDatesCheckBox.isChecked()) {
                if(theaterCheckBox.isChecked()) {
                    theaterCheckBox.setChecked(false);
                }

                tableLayout.setVisibility(View.VISIBLE);
            } else {
                tableLayout.setVisibility(View.GONE);
            }
        } else {
            if(twoDatesCheckBox.isChecked()) {
                twoDatesCheckBox.setChecked(false);

                tableLayout.setVisibility(View.GONE);
            }
        }
    }

    public void selectDate(final View view) {
        final AlertDialog.Builder dateDialog = new AlertDialog.Builder(this);

        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.date_change_dialog, null);
        dateDialog.setView(dialogView);
        dateDialog.setTitle("Select a date: ");

        SharedPreferences sharedPreferences
                = getSharedPreferences(FILTER_PREFERENCES, Context.MODE_PRIVATE);
        final SharedPreferences.Editor prefsEditor = sharedPreferences.edit();

        final DatePicker datePicker = (DatePicker) dialogView.findViewById(R.id.movieDatePicker);

        if(view.getTag().equals("start_date")) {
            String startDate;
            if ((startDate = sharedPreferences.getString(FILTER_START_DATE, null)) != null) {
                setDatePickerDate(datePicker, startDate);
            }
        }

        if(view.getTag().equals("end_date")) {
            String endDate;
            if ((endDate = sharedPreferences.getString(FILTER_END_DATE, null)) != null) {
                setDatePickerDate(datePicker, endDate);
            } else {
                setDatePickerDate(datePicker, "01-01-2000");
            }
        }

        dateDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Calendar calendar = Calendar.getInstance();
                calendar.set(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth());
                String dateFormat = simpleDateFormat.format(new Date(calendar.getTimeInMillis()));

                if (view.getTag().equals("start_date")) {
                    prefsEditor.putString(FILTER_START_DATE, dateFormat);
                } else {
                    prefsEditor.putString(FILTER_END_DATE, dateFormat);
                }

                prefsEditor.commit();

                if(view.getTag().equals("start_date")) {
                    Button button = (Button) findViewById(R.id.startDateButton);
                    button.setText(dateFormat);
                } else {
                    Button button = (Button) findViewById(R.id.endDateButton);
                    button.setText(dateFormat);
                }
            }
        });

        dateDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                return;
            }
        });

        dateDialog.show();
    }

    private void setDatePickerDate(DatePicker datePicker, String date) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(simpleDateFormat.parse(date));
            datePicker.init(calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH), null);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


    public void collapseAdvanced(View view) {
        final RelativeLayout advancedView = (RelativeLayout) findViewById(R.id.advancedView);
        ImageView collapseIcon = (ImageView) findViewById(R.id.collapseIcon);

        if (advancedView.getVisibility() == View.GONE) {
            expandAnimation(advancedView);
            collapseIcon.setImageResource(R.drawable.ic_keyboard_arrow_up_black_24dp);
        } else {
            collapseAnimation(advancedView);
            collapseIcon.setImageResource(R.drawable.ic_keyboard_arrow_down_black_24dp);
        }
    }


    private void collapseAnimation(final View view) {
        final int initialHeight = view.getMeasuredHeight();

        Animation collapse = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                if (interpolatedTime == 1) {
                    view.setVisibility(View.GONE);
                } else {
                    view.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    view.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        collapse.setDuration((int) (initialHeight / view.getContext().getResources().getDisplayMetrics().density));
        view.startAnimation(collapse);
    }


    private void expandAnimation(final View view) {
        view.measure(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        final int targetHeight = view.getMeasuredHeight();

        view.getLayoutParams().height = 1;
        view.setVisibility(View.VISIBLE);

        Animation expand = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                if (interpolatedTime == 1) {
                    view.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    ScrollView scrollView = (ScrollView) findViewById(R.id.scrollView);
                    scrollView.scrollTo(0, scrollView.getHeight());
                } else {
                    view.getLayoutParams().height = (int) (targetHeight * interpolatedTime);
                }

                view.requestLayout();
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        expand.setDuration((int) (targetHeight / view.getContext().getResources().getDisplayMetrics().density));
        view.startAnimation(expand);
    }
}
